module DoAn2 {
	requires java.desktop;
	requires java.sql;
}